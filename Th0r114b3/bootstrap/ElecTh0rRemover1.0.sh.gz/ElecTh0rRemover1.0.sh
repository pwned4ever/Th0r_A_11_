if [ "$EUID" -ne 0 ]; then
  echo "ERROR! You are not logged in as root user!"
  echo "Please login as root user before executing this script."
  exit
fi

echo "Jailbreak Remover by @pwned4ever for Electra 1131"
read -p "Press enter to continue. Press Ctrl + C to exit"

echo "Killing Cydia.."
killall Cydia

echo "Removing Cydia and other applications you may have downloaded from Cydia, then removing the binaries and bootstrap"

cd /
find *.deb -type f -delete
find . -name *.deb -type f -delete
find . -name *._ -type f -delete
# Applications cleanup


  
rm -rdvf /private/etc/motd
rm -rdvf /.cydia_no_stash
rm -rdvf /Applications/Cydia.app
rm -rdvf /usr/share/terminfo
rm -rdvf /usr/local/bin
rm -rdvf /usr/local/lib
rm -rdvf /authorize.sh
rm -rdvf /.cydia_no_stash
rm -rdvf /bin/zsh
rm -rdvf /private/etc/profile
rm -rdvf /etc/zshrc
rm -rdvf /usr/bin/scp
rm -rdvf /usr/lib/libsubstitute.0.dylib
rm -rdvf /usr/lib/libsubstitute.dylib
rm -rdvf /usr/lib/libsubstrate.dylib
rm -rdvf /usr/lib/libjailbreak.dylib
rm -rdvf /usr/bin/recache
rm -rdvf /usr/bin/rollectra
rm -rdvf /usr/bin/Rollectra
rm -rdvf /usr/bin/killall
rm -rdvf /usr/share/terminfo
rm -rdvf /usr/libexec/sftp-server
rm -rdvf /usr/lib/SBInject.dylib
rm -rdvf /bin/zsh
rm -rdvf /electra-prejailbreak
rm -rdvf /electra/createSnapshot
rm -rdvf /jb
rm -rf /RWTEST 
rm -rf /pwnedWritefileatrootTEST 
#Applications
rm -rdvf /Applications/Cydia\ Update\ Helper.app
rm -rdvf /Applications/AppCake.app
rm -rdvf /Applications/Activator.app
rm -rdvf /Applications/Anemone.app
rm -rdvf /Applications/BestCallerId.app
rm -rdvf /Applications/CrackTool3.app
rm -rdvf /Applications/Cydia.app
rm -rdvf /Applications/Rollectra.app
rm -rdvf /Applications/cydown.app
rm -rdvf /Applications/Cylinder.app
rm -rdvf /Applications/iCleaner.app
rm -rdvf /Applications/icleaner.app
rm -rdvf /Applications/BarrelSettings.app
rm -rdvf /Applications/Ext3nder.app
rm -rdvf /Applications/Filza.app
rm -rdvf /Applications/Flex.app
rm -rdvf /Applications/GBA4iOS.app
rm -rdvf /Applications/jjjj.app
rm -rdvf /Applications/SafeMode.app
rm -rdvf /Applications/NewTerm.app
rm -rdvf /Applications/MobileTerminal.app
rm -rdvf /Applications/MTerminal.app
rm -rdvf /Applications/MovieBox3.app
rm -rdvf /Applications/BobbyMovie.app
rm -rdvf /Applications/RST.app
rm -rdvf /Applications/TSSSaver.app
rm -rdvf /Applications/CertRemainTime.app
rm -rdvf /Applications/CrashReporter.app
rm -rdvf /Applications/AudioRecorder.app
rm -rdvf /Applications/ADManager.app
rm -rdvf /Applications/CocoaTop.app
rm -rdvf /Applications/calleridfaker.app
rm -rdvf /Applications/CallLogPro.app
rm -rdvf /Applications/WiFiPasswords.app
rm -rdvf /Applications/WifiPasswordList.app
rm -rdvf /Applications/calleridfaker.app
rm -rdvf /Applications/ClassDumpGUI.app
rm -rdvf /Applications/idevicewallsapp.app
rm -rdvf /Applications/UDIDFaker.app
rm -rdvf /Applications/UDIDCalculator.app
rm -rdvf /Applications/CallRecorder.app
rm -rdvf /Applications/Rehosts.app

#   ///////////USR/LIBEXEC
rm -rdvf /usr/libexec/as
rm -rdvf /usr/libexec/frcode
rm -rdvf /usr/libexec/bigram
rm -rdvf /usr/libexec/code
rm -rdvf /usr/libexec/reload
rm -rdvf /usr/libexec/rmt
rm -rdvf /usr/libexec/MSUnrestrictProcess
rm -rdvf /usr/libexec/substrate
rm -rdvf /usr/lib/perl5

 #//////////USR/SHARE
rm -rdvf /usr/share/terminfo
rm -rdvf /usr/share/dict
rm -rdvf /usr/share/git-core
rm -rdvf /usr/share/git-gui
rm -rdvf /usr/share/gitk
rm -rdvf /usr/share/gitweb
rm -rdvf /usr/share/man

   # ////////USR/LOCAL
rm -rdvf /usr/local/bin
rm -rdvf /usr/local/lib
rm -rdvf /usr/local/lib/libluajit.a

   # ////var
rm -rdvf /var/containers/Bundle/iosbinpack64

  #  ////etc folder cleanup
rm -rdvf /private/etc/pam.d

#//private/etc
rm -rdvf /private/etc/apt
rm -rdvf /private/etc/dropbear
rm -rdvf /private/etc/alternatives
rm -rdvf /private/etc/default
rm -rdvf /private/etc/dpkg
rm -rdvf /private/etc/ssh
rm -rdvf /private/etc/ssl
rm -rdvf /private/etc/profile.d


#////private/var
rm -rdvf /private/var/backups
rm -rdvf /private/var/cache
rm -rdvf /private/var/Ext3nder-Installer
rm -rdvf /private/var/lib
rm -rdvf /private/var/local
rm -rdvf /private/var/lock
rm -rdvf /private/var/spool
rm -rdvf /private/var/lib/apt
rm -rdvf /private/var/lib/dpkg
rm -rdvf /private/var/lib/dpkg
rm -rdvf /private/var/lib/cydia
rm -rdvf /private/var/cache/apt
rm -rdvf /private/var/db/stash
rm -rdvf /private/var/stash
rm -rdvf /private/var/tweak

#//var/mobile/Library

rm -rdvf /private/var/mobile/Library/Flex3
rm -rdvf /private/var/mobile/Library/Fingal
rm -rdvf /private/var/mobile/Library/Filza
rm -rdvf /private/var/mobile/Library/CT3
rm -rdvf /private/var/mobile/Library/Cydia

rm -rdvf /private/var/mobile/Library/com.saurik.Cydia
rm -rdvf /private/var/mobile/Library/com.saurik.Cydia/

rm -rdvf /private/var/mobile/Library/SBHTML
rm -rdvf /private/var/mobile/Library/LockHTML
rm -rdvf /private/var/mobile/Library/iWidgets

#//var/mobile/Library/Cache
rm -rdvf /private/var/mobile/Library/Application\ Support/Flex3
rm -rdvf /private/var/mobile/Library/Caches/libactivator.plist
rm -rdvf /private/var/mobile/Library/Caches/com.saurik.Cydia
rm -rdvf /private/var/mobile/Library/Caches/com.tigisoftware.Filza
rm -rdvf /private/var/mobile/Library/Caches/com.johncoates.Flex
rm -rdvf /private/var/mobile/Library/libactivator.plist
rm -rdvf /private/var/mobile/Library/Preferences/com.saurik.Cydia.plist
rm -rdvf /private/var/mobile/Library/Application\ Support/Activator
rm -rdvf /private/var/mobile/Library/Activator

#//snapshot.library
rm -rdvf /private/var/mobile/Library/Caches/Snapshots/com.saurik.Cydia
rm -rdvf /private/var/mobile/Library/Caches/Snapshots/com.tigisoft.Filza
rm -rdvf /private/var/mobile/Library/Caches/Snapshots/com.johncoates.Flex
rm -rdvf /private/var/mobile/Library/Caches/Snapshots/org.coolstar.SafeMode
rm -rdvf /private/var/mobile/Library/Caches/Snapshots/ws.hbang.Terminal
rm -rdvf /private/var/run/utmp

rm -rdvf /private/etc/apt/sources.list.d/cydia.list
rm -rdvf /private/etc/apt

 #////////usr files and folder
#////usr/share files
rm -rdvf /usr/share/bigboss
rm -rdvf /usr/share/dict
rm -rdvf /usr/share/dpkg
rm -rdvf /usr/share/gnupg
rm -rdvf /usr/share/tabset
rm -rdvf /usr/share/terminfo
#////usr/include files
rm -rdvf /usr/include
#////usr/local files
rm -rdvf /usr/local/bin
#////usr/libexec files
rm -rdvf /usr/libexec/apt
rm -rdvf /usr/libexec/ssh-pkcs11-helper
rm -rdvf /usr/libexec/ssh-keysign
rm -rdvf /usr/libexec/cydia
rm -rdvf /usr/libexec/dpkg
rm -rdvf /usr/libexec/gnupg
rm -rdvf /usr/libexec/gpg
rm -rdvf /usr/libexec/git-core
rm -rdvf /usr/libexec/frcode
rm -rdvf /usr/libexec/bigram
rm -rdvf /usr/libexec/code
rm -rdvf /usr/libexec/reload
rm -rdvf /usr/libexec/rmt
rm -rdvf /usr/libexec/filza
rm -rdvf /usr/libexec/sudo
#////usr/lib files
rm -rdvf /usr/lib/TweakInject
rm -rdvf /usr/lib/Activator
rm -rdvf /usr/lib/apt
rm -rdvf /usr/lib/dpkg
rm -rdvf /usr/lib/pam
rm -rdvf /usr/lib/pkgconfig
rm -rdvf /usr/lib/ssl
rm -rdvf /usr/lib/bash
rm -rdvf /usr/lib/coreutils
rm -rdvf /usr/lib/engines
rm -rdvf /usr/lib/p7zip
rm -rdvf /usr/lib/Cephei.framework
rm -rdvf /usr/lib/CepheiPrefs.framework
rm -rdvf /usr/lib/SBInject
#//usr/local
rm -rdvf /usr/local/bin
rm -rdvf /usr/local/lib
#////library folder files and subfolders
rm -rdvf /Library/Alkaline
rm -rdvf /Library/Activator
rm -rdvf /Library/Barrel
rm -rdvf /Library/BarrelSettings
rm -rdvf /Library/Cylinder
rm -rdvf /Library/dpkg
rm -rdvf /Library/Frameworks
rm -rdvf /Library/LaunchDaemons
rm -rdvf /Library/.DS_Store
rm -rdvf /Library/MobileSubstrate
rm -rdvf /Library/PreferenceBundles

rm -rdvf /Library/PreferenceLoader
rm -rdvf /Library/SBInject
rm -rdvf /Library/Application\ Support/Snoverlay
rm -rdvf /Library/Application\ Support/CallBlocker
rm -rdvf /Library/Application\ Support/Activator
rm -rdvf /Library/Application\ Support/Cylinder
rm -rdvf /Library/Application\ Support/Barrel
rm -rdvf /Library/Application\ Support/BarrelSettings
rm -rdvf /Library/Application\ Support/libGitHubIssues/
rm -rdvf /Library/Themes
rm -rdvf /Library/TweakInject
rm -rdvf /Library/Zeppelin
rm -rdvf /Library/Flipswitch
rm -rdvf /Library/Switches

#//////system/library
rm -rdvf /System/Library/PreferenceBundles/AppList.bundle
rm -rdvf /System/Library/Themes

#/////root

rm -rdvf /FELICITYICON.png
rm -rdvf /bootstrap
rm -rdvf /mnt
rm -rdvf /lib
rm -rdvf /boot
rm -rdvf /libexec
rm -rdvf /include
rm -rdvf /mnt
rm -rdvf /jb
rm -rdvf /usr/games
#//////////////USR/LIBRARY
rm -rdvf /usr/Library

#///////////PRIVATE
rm -rdvf /private/var/run/utmp

rm -rdvf /usr/bin/killall
rm -rdvf /usr/sbin/reboot
rm -rdvf /.bootstrapped_Th0r
rm -rf /Library/test_inject_springboard.cy
rm -rdvf /usr/lib/SBInject.dylib
# ////usr/local files and folders cleanup
rm -rdvf /usr/local/lib
    
rm -rdvf /usr/lib/libsparkapplist.dylib
    
rm -rdvf /usr/lib/libcrashreport.dylib
rm -rdvf /usr/lib/libsymbolicate.dylib
rm -rdvf /usr/lib/TweakInject.dylib
#    //////ROOT FILES :(
rm -rdvf /.bootstrapped_electra
rm -rdvf /.cydia_no_stash
rm -rdvf /.bit_of_fun
rm -rdvf /RWTEST
rm -rdvf /pwnedWritefileatrootTEST
rm -rdvf /private/etc/symlibs.dylib
   #BIN 
rm -rdvf /bin/bashbug
rm -rdvf /bin/bunzip2
rm -rdvf /bin/bzcat
rm -rdvf /bin/bzip2
rm -rdvf /bin/bzip2recover
rm -rdvf /bin/bzip2_64
rm -rdvf /bin/cat
rm -rdvf /bin/chgrp
rm -rdvf /bin/chmod
rm -rdvf /bin/chown
rm -rdvf /bin/cp
rm -rdvf /bin/date
rm -rdvf /bin/dd
rm -rdvf /bin/dir
rm -rdvf /bin/echo
rm -rdvf /bin/egrep
rm -rdvf /bin/false
rm -rdvf /bin/fgrep
rm -rdvf /bin/grep
rm -rdvf /bin/gzip
rm -rdvf /bin/gtar
rm -rdvf /bin/gunzip
rm -rdvf /bin/gzexe
rm -rdvf /bin/hostname
rm -rdvf /bin/launchctl
rm -rdvf /bin/ln
rm -rdvf /bin/ls
rm -rdvf /bin/jtoold
rm -rdvf /bin/kill
rm -rdvf /bin/mkdir
rm -rdvf /bin/mknod
rm -rdvf /bin/mv
rm -rdvf /bin/mktemp
rm -rdvf /bin/pwd
rm -rdvf /bin/rmdir
rm -rdvf /bin/readlink
rm -rdvf /bin/unlink
rm -rdvf /bin/run-parts
rm -rdvf /bin/su
rm -rdvf /bin/sync
rm -rdvf /bin/stty
rm -rdvf /bin/sh
rm -rdvf /bin/sleep
rm -rdvf /bin/sed
rm -rdvf /bin/su
rm -rdvf /bin/tar
rm -rdvf /bin/touch
rm -rdvf /bin/true
rm -rdvf /bin/uname
rm -rdvf /bin/vdr
rm -rdvf /bin/vdir
rm -rdvf /bin/uncompress
rm -rdvf /bin/znew
rm -rdvf /bin/zegrep
rm -rdvf /bin/zmore
rm -rdvf /bin/zdiff
rm -rdvf /bin/zcat
rm -rdvf /bin/zcmp
rm -rdvf /bin/zfgrep
rm -rdvf /bin/zforce
rm -rdvf /bin/zless
rm -rdvf /bin/zgrep
rm -rdvf /bin/zegrep
 #   //////////SBIN
rm -rdvf /sbin/reboot
rm -rdvf /sbin/halt
rm -rdvf /sbin/ifconfig
rm -rdvf /sbin/kextunload
rm -rdvf /sbin/ping
rm -rdvf /sbin/update_dyld_shared_cache
rm -rdvf /sbin/dmesg
rm -rdvf /sbin/dynamic_pager
rm -rdvf /sbin/nologin
  #  /////usr/bin files folders cleanup
 #   //symbols
rm -rdvf /usr/bin/[
#    //a
rm -rdvf /usr/bin/ADMHelper
rm -rdvf /usr/bin/arch
rm -rdvf /usr/bin/apt
rm -rdvf /usr/bin/ar   
rm -rdvf /usr/bin/apt-key
rm -rdvf /usr/bin/apt-cache
rm -rdvf /usr/bin/apt-cdrom
rm -rdvf /usr/bin/apt-config
rm -rdvf /usr/bin/apt-extracttemplates
rm -rdvf /usr/bin/apt-ftparchive
rm -rdvf /usr/bin/apt-sortpkgs
rm -rdvf /usr/bin/apt-mark
rm -rdvf /usr/bin/apt-get
rm -rdvf /usr/bin/arch
rm -rdvf /usr/bin/asu_inject
rm -rdvf /usr/bin/as
 #   //b
rm -rdvf /usr/bin/bashbug
rm -rdvf /usr/bin/b2sum
rm -rdvf /usr/bin/base32
rm -rdvf /usr/bin/base64
rm -rdvf /usr/bin/basename
rm -rdvf /usr/bin/bitcode_strip
#    //c
rm -rdvf /usr/bin/CallLogPro
rm -rdvf /usr/bin/com.julioverne.ext3nder-installer
rm -rdvf /usr/bin/chown
rm -rdvf /usr/bin/chmod
rm -rdvf /usr/bin/chroot
rm -rdvf /usr/bin/chcon
rm -rdvf /usr/bin/check_dylib
rm -rdvf /usr/bin/checksyms
rm -rdvf /usr/bin/chfn
rm -rdvf /usr/bin/chsh
rm -rdvf /usr/bin/cksum
rm -rdvf /usr/bin/comm
rm -rdvf /usr/bin/cmpdylib
rm -rdvf /usr/bin/codesign_allocate
rm -rdvf /usr/bin/csplit
rm -rdvf /usr/bin/ctf_insert
rm -rdvf /usr/bin/cut
rm -rdvf /usr/bin/curl
rm -rdvf /usr/bin/curl-config
rm -rdvf /usr/bin/c_rehash
rm -rdvf /usr/bin/captoinfo
rm -rdvf /usr/bin/cfversion
rm -rdvf /usr/bin/clear
rm -rdvf /usr/bin/cmp
rm -rdvf /usr/bin/cydown//cydown
rm -rdvf /usr/bin/cydown.arch_arm64
rm -rdvf /usr/bin/cydown.arch_armv7    
rm -rdvf /usr/bin/cycript
rm -rdvf /usr/bin/cycc
rm -rdvf /usr/bin/cynject
#    //d
rm -rdvf /usr/bin/dbclient
rm -rdvf /usr/bin/db_archive
rm -rdvf /usr/bin/db_checkpoint
rm -rdvf /usr/bin/db_deadlock
rm -rdvf /usr/bin/db_dump
rm -rdvf /usr/bin/db_hotbackup
rm -rdvf /usr/bin/db_load
rm -rdvf /usr/bin/db_log_verify
rm -rdvf /usr/bin/db_printlog
rm -rdvf /usr/bin/db_recover
rm -rdvf /usr/bin/db_replicate
rm -rdvf /usr/bin/db_sql_codegen
rm -rdvf /usr/bin/db_stat
rm -rdvf /usr/bin/db_tuner
rm -rdvf /usr/bin/db_upgrade
rm -rdvf /usr/bin/db_verify
rm -rdvf /usr/bin/dbsql
rm -rdvf /usr/bin/debugserver
rm -rdvf /usr/bin/defaults
rm -rdvf /usr/bin/df
rm -rdvf /usr/bin/diff
rm -rdvf /usr/bin/diff3
rm -rdvf /usr/bin/dirname
rm -rdvf /usr/bin/dircolors
rm -rdvf /usr/bin/dirmngr
rm -rdvf /usr/bin/dirmngr-client
rm -rdvf /usr/bin/dpkg
rm -rdvf /usr/bin/dpkg-architecture
rm -rdvf /usr/bin/dpkg-buildflags
rm -rdvf /usr/bin/dpkg-buildpackage
rm -rdvf /usr/bin/dpkg-checkbuilddeps
rm -rdvf /usr/bin/dpkg-deb
rm -rdvf /usr/bin/dpkg-distaddfile
rm -rdvf /usr/bin/dpkg-divert
rm -rdvf /usr/bin/dpkg-genbuildinfo
rm -rdvf /usr/bin/dpkg-genchanges
rm -rdvf /usr/bin/dpkg-gencontrol
rm -rdvf /usr/bin/dpkg-gensymbols
rm -rdvf /usr/bin/dpkg-maintscript-helper
rm -rdvf /usr/bin/dpkg-mergechangelogs
rm -rdvf /usr/bin/dpkg-name
rm -rdvf /usr/bin/dpkg-parsechangelog
rm -rdvf /usr/bin/dpkg-query
rm -rdvf /usr/bin/dpkg-scanpackages
rm -rdvf /usr/bin/dpkg-scansources
rm -rdvf /usr/bin/dpkg-shlibdeps
rm -rdvf /usr/bin/dpkg-source
rm -rdvf /usr/bin/dpkg-split
rm -rdvf /usr/bin/dpkg-statoverride
rm -rdvf /usr/bin/dpkg-trigger
rm -rdvf /usr/bin/dpkg-vendor
rm -rdvf /usr/bin/du
rm -rdvf /usr/bin/dumpsexp
rm -rdvf /usr/bin/dselect
rm -rdvf /usr/bin/dsymutil
  #  ////e
rm -rdvf /usr/bin/expand
rm -rdvf /usr/bin/expr
rm -rdvf /usr/bin/env
 #   //f
rm -rdvf /usr/bin/factor
rm -rdvf /usr/bin/filemon
rm -rdvf /usr/bin/Filza
rm -rdvf /usr/bin/fmt
rm -rdvf /usr/bin/fold
rm -rdvf /usr/bin/funzip
 #   //g
rm -rdvf /usr/bin/getconf
rm -rdvf /usr/bin/getty
rm -rdvf /usr/bin/git
rm -rdvf /usr/bin/git-cvsserver
rm -rdvf /usr/bin/git-recieve-pack
rm -rdvf /usr/bin/git-shell
rm -rdvf /usr/bin/git-upload-pack
rm -rdvf /usr/bin/gitk
rm -rdvf /usr/bin/gnutar
rm -rdvf /usr/bin/gpg
rm -rdvf /usr/bin/gpg-zip
rm -rdvf /usr/bin/gpgsplit
rm -rdvf /usr/bin/gpgv
rm -rdvf /usr/bin/gssc
rm -rdvf /usr/bin/groups
rm -rdvf /usr/bin/gpg-agent
rm -rdvf /usr/bin/gpg-connect-agent 
rm -rdvf /usr/bin/gpg-error
rm -rdvf /usr/bin/gpg-error-config
rm -rdvf /usr/bin/gpg2
rm -rdvf /usr/bin/gpgconf
rm -rdvf /usr/bin/gpgparsemail
rm -rdvf /usr/bin/gpgscm
rm -rdvf /usr/bin/gpgsm
rm -rdvf /usr/bin/gpgtar
rm -rdvf /usr/bin/gpgv2
rm -rdvf /usr/bin/groups
rm -rdvf /usr/bin/gtar
#    //h
rm -rdvf /usr/bin/head
rm -rdvf /usr/bin/hmac256
rm -rdvf /usr/bin/hostid
rm -rdvf /usr/bin/hostinfo
#    //i
rm -rdvf /usr/bin/install
rm -rdvf /usr/bin/id
rm -rdvf /usr/bin/indr
rm -rdvf /usr/bin/inout
rm -rdvf /usr/bin/infocmp
rm -rdvf /usr/bin/infotocap
rm -rdvf /usr/bin/iomfsetgamma
rm -rdvf /usr/bin/install_name_tool
rm -rdvf /usr/bin/libtool
rm -rdvf /usr/bin/lipo
#    //j
rm -rdvf /usr/bin/join
rm -rdvf /usr/bin/jtool
#    //k
rm -rdvf /usr/bin/killall
rm -rdvf /usr/bin/kbxutil
rm -rdvf /usr/bin/ksba-config
 #   //l
rm -rdvf /usr/bin/less
rm -rdvf /usr/bin/libassuan-config
rm -rdvf /usr/bin/libgcrypt-config
rm -rdvf /usr/bin/link
rm -rdvf /usr/bin/ldid
rm -rdvf /usr/bin/ldid2
rm -rdvf /usr/bin/ldrestart
rm -rdvf /usr/bin/locate
rm -rdvf /usr/bin/login
rm -rdvf /usr/bin/logname
rm -rdvf /usr/bin/lzcat
rm -rdvf /usr/bin/lzcmp
rm -rdvf /usr/bin/lzdiff
rm -rdvf /usr/bin/lzegrep
rm -rdvf /usr/bin/lzfgrep
rm -rdvf /usr/bin/lzgrep
rm -rdvf /usr/bin/lzless
rm -rdvf /usr/bin/lzma
rm -rdvf /usr/bin/lzmadec
rm -rdvf /usr/bin/lzmainfo
rm -rdvf /usr/bin/lzmore
rm -rdvf /usr/bin.lipo
rm -rdvf /usr/bin/lipo   
#    //m
rm -rdvf /usr/bin/md5sum
rm -rdvf /usr/bin/mkfifo
rm -rdvf /usr/bin/mktemp
rm -rdvf /usr/bin/more
rm -rdvf /usr/bin/mpicalc
#    //n
rm -rdvf /usr/bin/nano
rm -rdvf /usr/bin/nm
rm -rdvf /usr/bin/nmedit
rm -rdvf /usr/bin/nice
rm -rdvf /usr/bin/nl
rm -rdvf /usr/bin/nohup
rm -rdvf /usr/bin/nproc
rm -rdvf /usr/bin/npth-config
rm -rdvf /usr/bin/numfmt
rm -rdvf /usr/bin/ncurses6-config
rm -rdvf /usr/bin/ncursesw6-config
rm -rdvf /usr/bin/ncursesw5-config
rm -rdvf /usr/bin/ncurses5-config
#    //o
rm -rdvf /usr/bin/od
rm -rdvf /usr/bin/ObjectDump//ld64
rm -rdvf /usr/bin/dyldinfo
rm -rdvf /usr/bin/ld
rm -rdvf /usr/bin/machocheck
rm -rdvf /usr/bin/unwinddump
rm -rdvf /usr/bin/otool
rm -rdvf /usr/bin/openssl
#    //p
rm -rdvf /usr/bin/pincrush
rm -rdvf /usr/bin/pagestuff 
rm -rdvf /usr/bin/pagesize
rm -rdvf /usr/bin/passwd
rm -rdvf /usr/bin/paste
rm -rdvf /usr/bin/pathchk
rm -rdvf /usr/bin/pinky
rm -rdvf /usr/bin/plconvert
rm -rdvf /usr/bin/pr
rm -rdvf /usr/bin/printenv
rm -rdvf /usr/bin/printf
rm -rdvf /usr/bin/procexp
rm -rdvf /usr/bin/ptx
#    //r
rm -rdvf /usr/bin/renice
rm -rdvf /usr/bin/ranlib
rm -rdvf /usr/bin/redo_prebinding   
rm -rdvf /usr/bin/reset
rm -rdvf /usr/bin/realpath
rm -rdvf /usr/bin/rnano
rm -rdvf /usr/bin/runcon
#    //s    
rm -rdvf /usr/bin/snapUtil
rm -rdvf /usr/bin/sbdidlaunch
rm -rdvf /usr/bin/sbreload
rm -rdvf /usr/bin/script
rm -rdvf /usr/bin/sdiff
rm -rdvf /usr/bin/seq
rm -rdvf /usr/bin/seg_addr_table
rm -rdvf /usr/bin/seg_hack
rm -rdvf /usr/bin/segedit
rm -rdvf /usr/bin/sftp
rm -rdvf /usr/bin/shred
rm -rdvf /usr/bin/shuf
rm -rdvf /usr/bin/sort
rm -rdvf /usr/bin/ssh
rm -rdvf /usr/bin/ssh-add
rm -rdvf /usr/bin/ssh-agent
rm -rdvf /usr/bin/ssh-keygen
rm -rdvf /usr/bin/ssh-keyscan
rm -rdvf /usr/bin/sw_vers
rm -rdvf /usr/bin/seq
rm -rdvf /usr/bin/SemiRestore11-Lite  
rm -rdvf /usr/bin/sha1sum
rm -rdvf /usr/bin/sha224sum
rm -rdvf /usr/bin/sha256sum
rm -rdvf /usr/bin/sha384sum
rm -rdvf /usr/bin/sha512sum
rm -rdvf /usr/bin/shred
rm -rdvf /usr/bin/shuf
rm -rdvf /usr/bin/size
rm -rdvf /usr/bin/split
rm -rdvf /usr/bin/stat
rm -rdvf /usr/bin/stdbuf
rm -rdvf /usr/bin/strings
rm -rdvf /usr/bin/strip
rm -rdvf /usr/bin/sum
rm -rdvf /usr/bin/sync
 #   //t
rm -rdvf /usr/bin/tabs
rm -rdvf /usr/bin/tac
rm -rdvf /usr/bin/tar
rm -rdvf /usr/bin/tail
rm -rdvf /usr/bin/tee
rm -rdvf /usr/bin/test
rm -rdvf /usr/bin/tic
rm -rdvf /usr/bin/time
rm -rdvf /usr/bin/timeout
rm -rdvf /usr/bin/toe
rm -rdvf /usr/bin/tput
rm -rdvf /usr/bin/tr
rm -rdvf /usr/bin/tset
rm -rdvf /usr/bin/truncate
rm -rdvf /usr/bin/tsort
rm -rdvf /usr/bin/tty
#    //u
rm -rdvf /usr/bin/uiduid
rm -rdvf /usr/bin/uuid
rm -rdvf /usr/bin/uuid-config
rm -rdvf /usr/bin/uiopen
rm -rdvf /usr/bin/unlzma
rm -rdvf /usr/bin/unxz
rm -rdvf /usr/bin/update-alternatives
rm -rdvf /usr/bin/updatedb
rm -rdvf /usr/bin/unexpand
rm -rdvf /usr/bin/uniq
rm -rdvf /usr/bin/unzip
rm -rdvf /usr/bin/unzipsfx
rm -rdvf /usr/bin/unrar
rm -rdvf /usr/bin/uptime
rm -rdvf /usr/bin/users
#    //w
rm -rdvf /usr/bin/watchgnupg
rm -rdvf /usr/bin/wc
rm -rdvf /usr/bin/wget
rm -rdvf /usr/bin/which
rm -rdvf /usr/bin/who
rm -rdvf /usr/bin/whoami
#    //x
rm -rdvf /usr/bin/xargs
rm -rdvf /usr/bin/xz
rm -rdvf /usr/bin/xzcat
rm -rdvf /usr/bin/xzcmp
rm -rdvf /usr/bin/xzdec
rm -rdvf /usr/bin/xzdiff
rm -rdvf /usr/bin/xzegrep
rm -rdvf /usr/bin/xzfgrep
rm -rdvf /usr/bin/xzgrep
rm -rdvf /usr/bin/xzless
rm -rdvf /usr/bin/xzmore
#   //y
rm -rdvf /usr/bin/yes
#  //z
rm -rdvf /usr/bin/zip
rm -rdvf /usr/bin/zipcloak
rm -rdvf /usr/bin/zipnote
rm -rdvf /usr/bin/zipsplit
#  //numbers
rm -rdvf /usr/bin/7z
rm -rdvf /usr/bin/7za
#///////USR/SBIN
rm -rdvf /usr/sbin/chown
rm -rdvf /usr/sbin/chmod
rm -rdvf /usr/sbin/chroot
rm -rdvf /usr/sbin/applygnupgdefaults
rm -rdvf /usr/sbin/halt
rm -rdvf /usr/sbin/sshd
    
#////////////USR/LIB
rm -rdvf /usr/lib/libhistory.5.dylib
rm -rdvf /usr/lib/xxxMobileGestalt.dylib
rm -rdvf /usr/lib/xxxSystem.dylib    
rm -rdvf /usr/lib/libcolorpicker.dylib
rm -rdvf /usr/lib/libcrypto.dylib
rm -rdvf /usr/lib/libcrypto.a
rm -rdvf /usr/lib/libdb_sql-6.2.dylib
rm -rdvf /usr/lib/libdb_sql-6.dylib
rm -rdvf /usr/lib/libdb_sql.dylib
rm -rdvf /usr/lib/libdb-6.2.dylib
rm -rdvf /usr/lib/libdb-6.dylib
rm -rdvf /usr/lib/libdb.dylib
rm -rdvf /usr/lib/liblzma.a
rm -rdvf /usr/lib/liblzma.la
rm -rdvf /usr/lib/libprefs.dylib
rm -rdvf /usr/lib/libssl.a
rm -rdvf /usr/lib/libssl.dylib
rm -rdvf /usr/lib/libST.dylib
rm -rdvf /usr/lib/libapt-pkg.dylib.4.6
rm -rdvf /usr/lib/libapt-pkg.4.6.dylib
rm -rdvf /usr/lib/libpam.dylib
rm -rdvf /usr/lib/libpamc.1.dylib
rm -rdvf /usr/lib/libapt-pkg.dylib.4.6.0
rm -rdvf /usr/lib/libapt-pkg.4.6.0.dylib
rm -rdvf /usr/lib/libpanelw.5.dylib
rm -rdvf /usr/lib/libhistory.5.2.dylib
rm -rdvf /usr/lib/libreadline.6.dylib
rm -rdvf /usr/lib/libpanel.dylib
rm -rdvf /usr/lib/libapt-inst.dylib.1.1
rm -rdvf /usr/lib/libapt-inst.1.1.dylib
rm -rdvf /usr/lib/libcurses.dylib
rm -rdvf /usr/lib/liblzmadec.0.dylib
rm -rdvf /usr/lib/libhistory.6.dylib
rm -rdvf /usr/lib/libformw.dylib
rm -rdvf /usr/lib/libncursesw.dylib
rm -rdvf /usr/lib/libapt-inst.dylib
rm -rdvf /usr/lib/libncurses.5.dylib
rm -rdvf /usr/lib/libapt-pkg.dylib
rm -rdvf /usr/lib/libreadline.5.dylib
rm -rdvf /usr/lib/libhistory.6.0.dylib
rm -rdvf /usr/lib/libform.5.dylib
rm -rdvf /usr/lib/libpanelw.dylib
rm -rdvf /usr/lib/libmenuw.dylib
rm -rdvf /usr/lib/libform.dylib
rm -rdvf /usr/lib/terminfo
rm -rdvf /usr/lib/libpam.1.0.dylib
rm -rdvf /usr/lib/libmenu.5.dylib
rm -rdvf /usr/lib/libpatcyh.dylib
rm -rdvf /usr/lib/libreadline.6.0.dylib
rm -rdvf /usr/lib/liblzmadec.dylib
rm -rdvf /usr/lib/libncurses.dylib
rm -rdvf /usr/lib/libhistory.dylib
rm -rdvf /usr/lib/libpamc.dylib
rm -rdvf /usr/lib/libformw.5.dylib
rm -rdvf /usr/lib/libapt-inst.dylib.1.1.0
rm -rdvf /usr/lib/libapt-inst.1.1.0.dylib
rm -rdvf /usr/lib/libpanel.5.dylib
rm -rdvf /usr/lib/liblzmadec.0.0.0.dylib
rm -rdvf /usr/lib/_ncurses
rm -rdvf /usr/lib/libpam_misc.1.dylib
rm -rdvf /usr/lib/libreadline.5.2.dylib
rm -rdvf /usr/lib/libpam_misc.dylib
rm -rdvf /usr/lib/libreadline.dylib
rm -rdvf /usr/lib/libmenuw.5.dylib
rm -rdvf /usr/lib/libpam.1.dylib
rm -rdvf /usr/lib/libmenu.dylib
rm -rdvf /usr/lib/liblzmadec.la
rm -rdvf /usr/lib/libncursesw.5.dylib
rm -rdvf /usr/lib/libcycript.dylib
rm -rdvf /usr/lib/libcycript.jar
rm -rdvf /usr/lib/libdpkg.a
rm -rdvf /usr/lib/libcrypto.1.0.0.dylib
rm -rdvf /usr/lib/libssl.1.0.0.dylib
rm -rdvf /usr/lib/libcycript.db
rm -rdvf /usr/lib/libcurl.4.dylib
rm -rdvf /usr/lib/libcycript.0.dylib
rm -rdvf /usr/lib/libcycript.cy
rm -rdvf /usr/lib/libdpkg.la
rm -rdvf /usr/lib/libswift
rm -rdvf /usr/lib/libsubstrate.0.dylib
rm -rdvf /usr/lib/libuuid.16.dylib
rm -rdvf /usr/lib/libuuid.dylib
rm -rdvf /usr/lib/libsubstrate.0.dylib
rm -rdvf /usr/lib/libtapi.dylib//ld64
rm -rdvf /usr/lib/libnghttp2.14.dylib//ld64
rm -rdvf /usr/lib/libnghttp2.dylib//ld64
rm -rdvf /usr/lib/libnghttp2.la//ld64
 #   //////////USR/SBIN
rm -rdvf /usr/sbin/accton
rm -rdvf /usr/sbin/vifs
rm -rdvf /usr/sbin/ac
rm -rdvf /usr/sbin/update
rm -rdvf /usr/sbin/pwd_mkdb
rm -rdvf /usr/sbin/sysctl
rm -rdvf /usr/sbin/zdump
rm -rdvf /usr/sbin/startupfiletool
rm -rdvf /usr/sbin/iostat
rm -rdvf /usr/sbin/mkfile
rm -rdvf /usr/sbin/zic
rm -rdvf /usr/sbin/vipw
rm -rdvf /usr/sbin/start-stop-daemon
 #   ////////USR/LOCAL
rm -rdvf /usr/local/lib/libluajit.a
#  //////LIBRARY
rm -rdvf /Library/test_inject_springboard.cy
# //////sbin folder files cleanup
rm -rdvf /sbin/dmesg
    
rm -rdvf /sbin/cat
rm -rdvf /sbin/zshrc
#////usr/sbin files
rm -rdvf /usr/sbin/start-start-daemon
rm -rdvf /usr/sbin/accton
rm -rdvf /usr/sbin/vifs
rm -rdvf /usr/sbin/ac
rm -rdvf /usr/sbin/update
rm -rdvf /usr/sbin/sysctl
rm -rdvf /usr/sbin/zdump
rm -rdvf /usr/sbin/startupfiletool
rm -rdvf /usr/sbin/iostat
rm -rdvf /usr/sbin/mkfile
rm -rdvf /usr/sbin/zic
rm -rdvf /usr/sbin/vipw
#////usr/libexec files
rm -rdvf /usr/libexec/_rocketd_reenable
rm -rdvf /usr/libexec/rocketd
rm -rdvf /usr/libexec/MSUnrestrictProcess
rm -rdvf /usr/libexec/substrate
rm -rdvf /usr/lib/applist.dylib
rm -rdvf /usr/lib/libapplist.dylib
rm -rdvf /usr/lib/libhAcxTools.dylib
rm -rdvf /usr/lib/libhAcxTools2.dylib
rm -rdvf /usr/lib/libflipswitch.dylib
rm -rdvf /usr/lib/libapt-inst.2.0.0.dylib
rm -rdvf /usr/lib/libapt-inst.2.0.dylib
rm -rdvf /usr/lib/libapt-pkg.5.0.1.dylib
rm -rdvf /usr/lib/libapt-pkg.5.0.dylib
rm -rdvf /usr/lib/libapt-private.0.0.0.dylib
rm -rdvf /usr/lib/libapt-private.0.0.dylib
rm -rdvf /usr/lib/libassuan.0.dylib
rm -rdvf /usr/lib/libassuan.dylib
rm -rdvf /usr/lib/libassuan.la
rm -rdvf /usr/lib/libnpth.0.dylib
rm -rdvf /usr/lib/libnpth.dylib
rm -rdvf /usr/lib/libnpth.la
rm -rdvf /usr/lib/libgpg-error.0.dylib
rm -rdvf /usr/lib/libgpg-error.dylib
rm -rdvf /usr/lib/libgpg-error.la
rm -rdvf /usr/lib/libksba.8.dylib
rm -rdvf /usr/lib/libksba.dylib
rm -rdvf /usr/lib/libksba.la
rm -rdvf /usr/lib/cycript0.9
rm -rdvf /usr/lib/libhistory.5.dylib
rm -rdvf /usr/lib/libapt-pkg.dylib.4.6
rm -rdvf /usr/lib/libapt-pkg.4.6.dylib
rm -rdvf /usr/lib/libpam.dylib
rm -rdvf /usr/lib/libpamc.1.dylib
rm -rdvf /usr/lib/libpackageinfo.dylib
rm -rdvf /usr/lib/librocketbootstrap.dylib
rm -rdvf /usr/lib/libapt-pkg.dylib.4.6.0
rm -rdvf /usr/lib/libapt-pkg.4.6.0.dylib
rm -rdvf /usr/lib/libpanelw.5.dylib
rm -rdvf /usr/lib/libhistory.5.2.dylib
rm -rdvf /usr/lib/libreadline.6.dylib
rm -rdvf /usr/lib/libpanel.dylib
rm -rdvf /usr/lib/libapt-inst.dylib.1.1
rm -rdvf /usr/lib/libapt-inst.1.1.dylib
rm -rdvf /usr/lib/libcurses.dylib
rm -rdvf /usr/lib/liblzmadec.0.dylib
rm -rdvf /usr/lib/libhistory.6.dylib
rm -rdvf /usr/lib/libformw.dylib
rm -rdvf /usr/lib/libncursesw.dylib
rm -rdvf /usr/lib/libncurses.5.dylib
rm -rdvf /usr/lib/libreadline.5.dylib
rm -rdvf /usr/lib/libhistory.6.0.dylib
rm -rdvf /usr/lib/libform.5.dylib
rm -rdvf /usr/lib/libpanelw.dylib
rm -rdvf /usr/lib/libmenuw.dylib
rm -rdvf /usr/lib/libform.dylib
rm -rdvf /usr/lib/terminfo
rm -rdvf /usr/lib/terminfo
rm -rdvf /usr/lib/libpam.1.0.dylib
rm -rdvf /usr/lib/libmenu.5.dylib
rm -rdvf /usr/lib/libpatcyh.dylib
rm -rdvf /usr/lib/libreadline.6.0.dylib
rm -rdvf /usr/lib/liblzmadec.dylib
rm -rdvf /usr/lib/libncurses.dylib
rm -rdvf /usr/lib/libhistory.dylib
rm -rdvf /usr/lib/libpamc.dylib
rm -rdvf /usr/lib/libformw.5.dylib
rm -rdvf /usr/lib/libapt-inst.dylib.1.1.0
rm -rdvf /usr/lib/libapt-inst.1.1.0.dylib
rm -rdvf /usr/lib/libpanel.5.dylib
rm -rdvf /usr/lib/liblzmadec.0.0.0.dylib
rm -rdvf /usr/lib/_ncurses
rm -rdvf /usr/lib/libpam_misc.1.dylib
rm -rdvf /usr/lib/libreadline.5.2.dylib
rm -rdvf /usr/lib/libpam_misc.dylib
rm -rdvf /usr/lib/libreadline.dylib
rm -rdvf /usr/lib/libmenuw.5.dylib
rm -rdvf /usr/lib/libpam.1.dylib
rm -rdvf /usr/lib/libmenu.dylib
rm -rdvf /usr/lib/liblzmadec.la
rm -rdvf /usr/lib/libncursesw.5.dylib
rm -rdvf /usr/lib/libcycript.dylib
rm -rdvf /usr/lib/libcycript.jar
rm -rdvf /usr/lib/libcycript.db
rm -rdvf /usr/lib/libcurl.4.dylib
rm -rdvf /usr/lib/libcurl.dylib
rm -rdvf /usr/lib/libcurl.la
rm -rdvf /usr/lib/libcycript.0.dylib
rm -rdvf /usr/lib/libcycript.cy
rm -rdvf /usr/lib/libsubstrate.0.dylib
rm -rdvf /usr/lib/libcephei.dylib
rm -rdvf /usr/lib/libcepheiprefs.dylib
rm -rdvf /usr/lib/libhbangcommon.dylib
rm -rdvf /usr/lib/libhbangprefs.dylib
rm -rdvf /usr/lib/libjailbreak.dylib
rm -rdvf /var/profile
rm -rdvf /var/motd
rm -rdvf /var/log/testbin.log
rm -rdvf /var/log/jailbreakd-stderr.log
rm -rdvf /var/log/jailbreakd-stdout.log
rm -rdvf /Library/test_inject_springboard.cy
rm -rdvf /usr/local/lib/libluajit.a
rm -rdvf /bin/zsh
rm -rdvf /var/LIB
rm -rdvf /var/bin
rm -rdvf /var/sbin
rm -rdvf /var/profile
rm -rdvf /var/motd
rm -rdvf /var/dropbear
rm -rdvf /var/containers/Bundle/tweaksupport
rm -rdvf /var/containers/Bundle/iosbinpack64
rm -rdvf /var/containers/Bundle/dylibs
rm -rdvf /var/LIB
rm -rdvf /var/motd
rm -rdvf /var/log/testbin.log
rm -rdvf /var/log/jailbreakd-stdout.log
rm -rdvf /var/log/jailbreakd-stderr.log
rm -rdvf /usr/bin/find
rm -rdvf /jb
rm -rdvf /usr/bin/unlink


# Resetting hosts file
echo "Fixing up hosts file.."
echo "##" > /etc/hosts
echo "# Host Database" >> /etc/hosts
echo "#" >> /etc/hosts
echo "# localhost is used to configure the loopback interface" >> /etc/hosts
echo "# when the system is booting.  Do not change this entry." >> /etc/hosts
echo "##" >> /etc/hosts
echo "127.0.0.1	localhost" >> /etc/hosts
echo "255.255.255.255	broadcasthost" >> /etc/hosts
echo "::1 localhost" >> /etc/hosts

#comments??
echo "Running UIcache.."
uicache

rm -rf /usr/sbin/reboot 
rm -rf /sbin/reboot 
rm -rf /bootstrap/
rm -rf /usr/bin/uicache
rm -rdvf /usr/bin/snappy
rm -rf /bin/bash 
rm -rf /bin/sh
rm -rf /ElectraRemover.sh
rm -rf /electra/bootstrap.tar
rm -rf /electra
rm -rf /Th0r
rm -rf /bin/rm

echo "All tonne of jailbreak related files have been removed!"
echo "About to Reboot! Thanks for using it @pwned4ever)"
kill 1